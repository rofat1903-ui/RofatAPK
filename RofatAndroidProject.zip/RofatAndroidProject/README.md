# RofatAPK

Project Android WebView untuk menjalankan `rofat.html` sebagai aplikasi Android.

## Cara build
1. Buka folder ini di Android Studio.
2. Tunggu Gradle Sync selesai.
3. Pilih **Build > Build APK(s)**.
4. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

File HTML ada di:
`app/src/main/assets/rofat.html`
